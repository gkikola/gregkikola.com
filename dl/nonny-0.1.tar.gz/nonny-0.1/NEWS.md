Nonny Release Notes
===================

Nonny 0.1 (2017-06-14)
----------------------

Initial release
* Play and create nonogram puzzles
* Supports both black and white as well as multicolor puzzles
* Built-in solver
